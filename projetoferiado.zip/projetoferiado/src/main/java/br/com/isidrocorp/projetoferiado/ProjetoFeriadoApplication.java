package br.com.isidrocorp.projetoferiado;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjetoFeriadoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjetoFeriadoApplication.class, args);
	}

}
